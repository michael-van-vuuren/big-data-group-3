package com.Backend.Backend.dto;

import com.Backend.Backend.entity.Product;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ProductResponseDTO {
    private Long id;
    private String name;
    private String image;
    private String webpage;
    private BigDecimal gram;
    private String roastDegree;
    private String availability;
    private BigDecimal price;
    private BigDecimal pricePerCup;
    private BigDecimal bulkPricePerCup;

    private RoasterDTO roaster;

    private ProcessDTO process;

    private List<FlavorDTO> flavors;

    private List<ProducerDTO> producers;

    public static ProductResponseDTO fromEntity(Product product) {
        if (product == null) {
            return null;
        }
        return new ProductResponseDTO(
                product.getId(),
                product.getName(),
                product.getImage(),
                product.getWebpage(),
                product.getGram(),
                product.getRoastDegree(),
                product.getAvailability().name(),
                product.getPrice(),
                product.getPricePerCup(),
                product.getBulkPricePerCup(),
                RoasterDTO.fromEntity(product.getRoaster()),
                ProcessDTO.fromEntity(product.getProcess()),
                product.getFlavors() == null ? List.of() :
                        product.getFlavors().stream()
                                .filter(Objects::nonNull)
                                .map(FlavorDTO::fromEntity)
                                .toList(),
                product.getProducers() == null ? List.of() :
                        product.getProducers().stream()
                                .filter(Objects::nonNull)
                                .map(ProducerDTO::fromEntity)
                                .toList()
        );
    }

}
